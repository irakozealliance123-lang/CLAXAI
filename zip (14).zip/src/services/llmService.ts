import { KeyRotator } from '../lib/KeyRotator';
import { GoogleGenAI } from '@google/genai';

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export class LLMService {
  groqRotator: KeyRotator;
  openRouterRotator: KeyRotator;
  cohereRotator: KeyRotator;
  geminiRotator: KeyRotator;
  mistralRotator: KeyRotator;
  huggingFaceRotator: KeyRotator;

  constructor(groqKeys: string[], openRouterKeys: string[], cohereKeys: string[] = [], geminiKeys: string[] = [], mistralKeys: string[] = [], huggingFaceKeys: string[] = []) {
    this.groqRotator = new KeyRotator('Groq', groqKeys);
    this.openRouterRotator = new KeyRotator('OpenRouter', openRouterKeys);
    this.cohereRotator = new KeyRotator('Cohere', cohereKeys);
    this.geminiRotator = new KeyRotator('Gemini', geminiKeys);
    this.mistralRotator = new KeyRotator('Mistral', mistralKeys);
    this.huggingFaceRotator = new KeyRotator('HuggingFace', huggingFaceKeys);
  }

  updateKeys(groqKeys: string[], openRouterKeys: string[], cohereKeys: string[] = [], geminiKeys: string[] = [], mistralKeys: string[] = [], huggingFaceKeys: string[] = []) {
    this.groqRotator.updateKeys(groqKeys);
    this.openRouterRotator.updateKeys(openRouterKeys);
    this.cohereRotator.updateKeys(cohereKeys);
    this.geminiRotator.updateKeys(geminiKeys);
    this.mistralRotator.updateKeys(mistralKeys);
    this.huggingFaceRotator.updateKeys(huggingFaceKeys);
  }

  async sendMessage(
    messages: Message[], 
    onLog: (msg: string, type: 'info' | 'error' | 'success' | 'warning') => void,
    simulateRateLimit: boolean = false,
    collaborative: boolean = false,
    onChunk?: (chunk: string) => void,
    isProMode: boolean = false
  ): Promise<string> {
    
    if (isProMode) {
      onLog('PRO MODE ENABLED: Routing strictly to Gemini 3.1 Pro (Smartest Model) with Search Grounding.', 'info');
      const geminiResult = await this.tryGemini(messages, onLog, onChunk, true);
      if (geminiResult) return geminiResult;
      onLog('PRO MODE Gemini 3.1 Pro failed. Falling back to standards.', 'warning');
    }

    if (collaborative) {
      onLog('Collaborative mode enabled. Groq will draft, OpenRouter will refine.', 'info');
      
      // Step 1: Groq Draft
      let draft = await this.tryProvider(
        this.groqRotator, 
        'https://api.groq.com/openai/v1/chat/completions', 
        'llama-3.3-70b-versatile', 
        messages, 
        onLog,
        simulateRateLimit
      );
      
      if (!draft) {
        draft = await this.tryProvider(
          this.groqRotator, 
          'https://api.groq.com/openai/v1/chat/completions', 
          'llama-3.1-8b-instant', 
          messages, 
          onLog,
          simulateRateLimit
        );
      }

      // Step 2: OpenRouter Refinement
      if (draft) {
        onLog('Groq draft complete. Passing to OpenRouter for collaborative refinement...', 'info');
        const refineMessages: Message[] = [
          ...messages,
          { role: 'assistant', content: draft },
          { role: 'user', content: 'Please review, refine, and enhance the above response. Make it more comprehensive, accurate, and perfectly formatted. Do not mention that you are refining a previous response, just provide the final polished output.' }
        ];

        let final = await this.tryProvider(
          this.openRouterRotator, 
          'https://openrouter.ai/api/v1/chat/completions', 
          'meta-llama/llama-3.3-70b-instruct:free', 
          refineMessages, 
          onLog,
          simulateRateLimit,
          onChunk
        );

        if (!final) {
          final = await this.tryProvider(
            this.openRouterRotator, 
            'https://openrouter.ai/api/v1/chat/completions', 
            'google/gemini-2.0-flash-lite-preview-02-05:free', 
            refineMessages, 
            onLog,
            simulateRateLimit,
            onChunk
          );
        }

        if (final) {
          onLog('Collaborative refinement complete.', 'success');
          return final;
        }
        
        onLog('OpenRouter refinement failed. Returning Groq draft.', 'warning');
        return draft;
      }
      
      onLog('Groq failed to draft. Falling back to standard OpenRouter generation.', 'warning');
    }

    // Task Classification
    const lastMessage = messages[messages.length - 1].content.toLowerCase();
    let taskType = 'general';
    if (/(code|script|function|debug|html|css|react|typescript|python|javascript|api|database|sql)/i.test(lastMessage)) {
      taskType = 'coding';
    } else if (/(write|essay|poem|story|blog|creative|generate|draft)/i.test(lastMessage)) {
      taskType = 'creative';
    } else if (/(analyze|summarize|explain|research|compare|data)/i.test(lastMessage)) {
      taskType = 'analytical';
    }

    onLog(`Task classified as: ${taskType.toUpperCase()}`, 'info');

    let result: string | null = null;

    if (taskType === 'coding') {
      // 1. OpenRouter (Llama 3.3 70B Instruct - great at logic)
      result = await this.tryProvider(this.openRouterRotator, 'https://openrouter.ai/api/v1/chat/completions', 'meta-llama/llama-3.3-70b-instruct:free', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.mistralRotator, 'https://api.mistral.ai/v1/chat/completions', 'mistral-large-latest', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.groqRotator, 'https://api.groq.com/openai/v1/chat/completions', 'llama-3.3-70b-versatile', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.cohereRotator, 'https://api.cohere.com/v1/chat/completions', 'command-r-plus', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.huggingFaceRotator, 'https://api-inference.huggingface.co/models/meta-llama/Llama-3.3-70B-Instruct/v1/chat/completions', 'meta-llama/Llama-3.3-70B-Instruct', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryGemini(messages, onLog, onChunk);
    } else if (taskType === 'creative') {
      // 1. Cohere (Command R+ is great for writing)
      result = await this.tryProvider(this.cohereRotator, 'https://api.cohere.com/v1/chat/completions', 'command-r-plus', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.mistralRotator, 'https://api.mistral.ai/v1/chat/completions', 'mistral-large-latest', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.openRouterRotator, 'https://openrouter.ai/api/v1/chat/completions', 'meta-llama/llama-3.3-70b-instruct:free', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.groqRotator, 'https://api.groq.com/openai/v1/chat/completions', 'llama-3.3-70b-versatile', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.huggingFaceRotator, 'https://api-inference.huggingface.co/models/meta-llama/Llama-3.3-70B-Instruct/v1/chat/completions', 'meta-llama/Llama-3.3-70B-Instruct', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryGemini(messages, onLog, onChunk);
    } else if (taskType === 'analytical') {
      // 1. Mistral (Large is great for reasoning/analysis)
      result = await this.tryProvider(this.mistralRotator, 'https://api.mistral.ai/v1/chat/completions', 'mistral-large-latest', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.groqRotator, 'https://api.groq.com/openai/v1/chat/completions', 'llama-3.3-70b-versatile', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.openRouterRotator, 'https://openrouter.ai/api/v1/chat/completions', 'meta-llama/llama-3.3-70b-instruct:free', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.cohereRotator, 'https://api.cohere.com/v1/chat/completions', 'command-r-plus', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.huggingFaceRotator, 'https://api-inference.huggingface.co/models/meta-llama/Llama-3.3-70B-Instruct/v1/chat/completions', 'meta-llama/Llama-3.3-70B-Instruct', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryGemini(messages, onLog, onChunk);
    } else {
      // General - optimize for speed (Groq)
      result = await this.tryProvider(this.groqRotator, 'https://api.groq.com/openai/v1/chat/completions', 'llama-3.3-70b-versatile', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.openRouterRotator, 'https://openrouter.ai/api/v1/chat/completions', 'meta-llama/llama-3.3-70b-instruct:free', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.mistralRotator, 'https://api.mistral.ai/v1/chat/completions', 'mistral-large-latest', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.cohereRotator, 'https://api.cohere.com/v1/chat/completions', 'command-r-plus', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryProvider(this.huggingFaceRotator, 'https://api-inference.huggingface.co/models/meta-llama/Llama-3.3-70B-Instruct/v1/chat/completions', 'meta-llama/Llama-3.3-70B-Instruct', messages, onLog, simulateRateLimit, onChunk);
      if (!result) result = await this.tryGemini(messages, onLog, onChunk);
    }

    if (result) return result;

    throw new Error('All keys for all providers are exhausted or failed.');
  }

  private async tryGemini(
    messages: Message[],
    onLog: (msg: string, type: 'info' | 'error' | 'success' | 'warning') => void,
    onChunk?: (chunk: string) => void,
    isProMode: boolean = false
  ): Promise<string | null> {
    let attempts = 0;
    const maxAttempts = this.geminiRotator.getTotalCount();

    // If no keys provided in rotator, fallback to env variable
    if (maxAttempts === 0) {
      try {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
          onLog('Gemini API key is not configured.', 'error');
          return null;
        }
        onLog('Trying Gemini with environment API key...', 'info');
        return await this.executeGeminiRequest(apiKey, messages, onLog, onChunk, isProMode);
      } catch (error: any) {
        onLog(`Gemini API error: ${error.message}`, 'error');
        return null;
      }
    }

    // Use rotator keys
    while (attempts < maxAttempts) {
      attempts++;
      const keyInfo = this.geminiRotator.getNextKey();
      if (!keyInfo) {
        onLog('All Gemini keys are exhausted.', 'error');
        return null;
      }

      onLog(`Trying Gemini key #${keyInfo.index + 1}...`, 'info');

      try {
        const result = await this.executeGeminiRequest(keyInfo.key, messages, onLog, onChunk, isProMode);
        if (result) return result;
      } catch (error: any) {
        onLog(`Gemini API error with key #${keyInfo.index + 1}: ${error.message}`, 'error');
        
        // Check if it's a quota or rate limit error
        const errMsg = error.message.toLowerCase();
        if (errMsg.includes('quota') || errMsg.includes('429') || errMsg.includes('exhausted')) {
          onLog(`Gemini key #${keyInfo.index + 1} hit quota limit. Marking as exhausted.`, 'warning');
          this.geminiRotator.markExhausted(keyInfo.index);
          continue;
        }
        
        // For other errors (like 400 Bad Request), stop trying
        return null;
      }
    }
    
    return null;
  }

  private async executeGeminiRequest(
    apiKey: string,
    messages: Message[],
    onLog: (msg: string, type: 'info' | 'error' | 'success' | 'warning') => void,
    onChunk?: (chunk: string) => void,
    isProMode: boolean = false
  ): Promise<string | null> {
    const ai = new GoogleGenAI({ apiKey });
    
    let systemInstruction = '';
    const geminiMessages = [];
    
    for (const msg of messages) {
      if (msg.role === 'system') {
        systemInstruction += msg.content + '\n';
      } else {
        geminiMessages.push({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: msg.content }]
        });
      }
    }

    const modelName = isProMode ? 'gemini-3.1-pro-preview' : 'gemini-3-flash-preview';
    const config: any = {
      systemInstruction: systemInstruction ? systemInstruction.trim() : undefined,
    };

    if (isProMode) {
      config.tools = [{ googleSearch: {} }];
    }

    if (onChunk) {
      const resultStream = await ai.models.generateContentStream({
        model: modelName,
        contents: geminiMessages,
        config
      });
      
      let fullContent = '';
      for await (const chunk of resultStream) {
        if (chunk.text) {
          fullContent += chunk.text;
          onChunk(chunk.text);
        }
      }
      onLog('Successfully got streamed response from Gemini.', 'success');
      return fullContent;
    } else {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: geminiMessages,
        config
      });

      if (response.text) {
        onLog('Successfully got response from Gemini.', 'success');
        return response.text;
      }
    }
    return null;
  }

  private async tryProvider(
    rotator: KeyRotator, 
    endpoint: string, 
    model: string, 
    messages: Message[],
    onLog: (msg: string, type: 'info' | 'error' | 'success' | 'warning') => void,
    simulateRateLimit: boolean,
    onChunk?: (chunk: string) => void
  ): Promise<string | null> {
    let attempts = 0;
    const maxAttempts = rotator.getTotalCount();

    while (attempts < maxAttempts) {
      attempts++;
      const keyInfo = rotator.getNextKey();
      if (!keyInfo) {
        onLog(`All ${rotator.name} keys are exhausted.`, 'error');
        return null;
      }

      onLog(`Trying ${rotator.name} key #${keyInfo.index + 1} with model ${model}...`, 'info');

      if (simulateRateLimit && Math.random() < 0.5) {
        onLog(`[SIMULATED] ${rotator.name} key #${keyInfo.index + 1} hit rate limit (429). Marking as exhausted.`, 'warning');
        rotator.markExhausted(keyInfo.index);
        continue;
      }

      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${keyInfo.key}`,
            ...(rotator.name === 'OpenRouter' ? {
              'HTTP-Referer': window.location.href,
              'X-Title': 'CLAX AI'
            } : {})
          },
          body: JSON.stringify({
            model: model,
            messages: messages,
            stream: !!onChunk && rotator.name !== 'Cohere' // Cohere streaming is different, disable for now
          })
        });

        if (response.status === 429) {
          onLog(`${rotator.name} key #${keyInfo.index + 1} hit rate limit (429). Marking as exhausted.`, 'warning');
          rotator.markExhausted(keyInfo.index);
          continue; 
        }

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          const errMsg = errorData?.error?.message?.toLowerCase() || '';
          
          if (response.status === 401 || response.status === 403) {
            onLog(`${rotator.name} key #${keyInfo.index + 1} is invalid/forbidden (${response.status}). Marking as exhausted.`, 'error');
            rotator.markExhausted(keyInfo.index);
            continue;
          }

          if (errMsg.includes('quota') || errMsg.includes('limit') || errMsg.includes('insufficient_quota')) {
            onLog(`${rotator.name} key #${keyInfo.index + 1} hit quota limit. Marking as exhausted.`, 'warning');
            rotator.markExhausted(keyInfo.index);
            continue;
          }
          
          if (response.status === 400 || response.status === 404) {
            onLog(`${rotator.name} API error ${response.status}: Bad request or model not found (${errMsg}). Stopping provider for this model.`, 'error');
            return null; // Don't exhaust keys for a bad request/model, just stop and let caller try fallback model
          }
          
          onLog(`${rotator.name} API error: ${response.status} ${response.statusText}`, 'error');
          rotator.markExhausted(keyInfo.index);
          continue;
        }

        if (onChunk && rotator.name !== 'Cohere' && response.body) {
          const reader = response.body.getReader();
          const decoder = new TextDecoder();
          let fullContent = '';
          
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n');
            for (const line of lines) {
              if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                try {
                  const data = JSON.parse(line.slice(6));
                  if (data.choices && data.choices[0].delta && data.choices[0].delta.content) {
                    const text = data.choices[0].delta.content;
                    fullContent += text;
                    onChunk(text);
                  }
                } catch (e) {}
              }
            }
          }
          onLog(`Successfully got streamed response from ${rotator.name} using key #${keyInfo.index + 1}.`, 'success');
          return fullContent;
        }

        const data = await response.json();
        if (data.choices && data.choices.length > 0) {
          onLog(`Successfully got response from ${rotator.name} using key #${keyInfo.index + 1}.`, 'success');
          return data.choices[0].message.content;
        } else {
          onLog(`${rotator.name} returned empty choices.`, 'error');
          return null;
        }

      } catch (error: any) {
        onLog(`Network error with ${rotator.name} key #${keyInfo.index + 1}: ${error.message}`, 'error');
        rotator.markExhausted(keyInfo.index);
        continue;
      }
    }
    
    return null;
  }
}
