export class GoogleDriveService {
  static async uploadDataset(token: string, jsonlData: string) {
    // 1. Search for existing file
    const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=name='CLAX_AI_Dataset.jsonl' and trashed=false`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    if (!searchRes.ok) {
      if (searchRes.status === 401) {
        throw new Error('Failed to search Google Drive. Token may be expired.');
      }
      if (searchRes.status === 403) {
        console.warn('Google Drive API returned 403 Forbidden. This usually means the Google Drive API is not enabled in the Google Cloud project for this Firebase app, or the user denied permission.');
        return null; // Gracefully fail if Drive API is not enabled
      }
      throw new Error(`Failed to search Google Drive. Status: ${searchRes.status}`);
    }
    
    const searchData = await searchRes.json();
    const existingFile = searchData.files && searchData.files.length > 0 ? searchData.files[0] : null;

    const metadata = {
      name: 'CLAX_AI_Dataset.jsonl',
      mimeType: 'application/json',
    };

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', new Blob([jsonlData], { type: 'application/json' }));

    let url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    let method = 'POST';

    if (existingFile) {
      url = `https://www.googleapis.com/upload/drive/v3/files/${existingFile.id}?uploadType=multipart`;
      method = 'PATCH';
    }

    const response = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: form,
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Failed to upload to Google Drive. Token may be expired.');
      }
      if (response.status === 403) {
        console.warn('Google Drive API returned 403 Forbidden during upload. The API might not be enabled or permission was denied.');
        return null;
      }
      throw new Error(`Failed to upload to Google Drive. Status: ${response.status}`);
    }

    return await response.json();
  }
}
