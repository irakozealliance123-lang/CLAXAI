import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CloudSun, Newspaper, Monitor, TrendingUp, Film, Radio } from 'lucide-react';
import { cn } from '../lib/utils';

interface TickerItem {
  id: string;
  text: string;
  type: 'weather' | 'tech' | 'market' | 'entertainment' | 'news';
  link?: string;
}

export function LiveTicker({ isStudyMode, isEnabled }: { isStudyMode?: boolean, isEnabled?: boolean }) {
  const [items, setItems] = useState<TickerItem[]>([
    { id: 'init', text: 'Connecting to live data streams...', type: 'news' }
  ]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function loadData() {
      const newItems: TickerItem[] = [];

      // 1. Fetch Weather (Non-blocking)
      const fetchWeather = async () => {
        try {
          let lat = 51.5074;
          let lon = -0.1278;
          let city = 'London';
          
          try {
            const locRes = await fetch('https://get.geojs.io/v1/ip/geo.json');
            if (locRes.ok) {
              const locData = await locRes.json();
              lat = locData.latitude || lat;
              lon = locData.longitude || lon;
              city = locData.city || 'Local';
            }
          } catch (locErr) {
            // Silently fallback to default location
          }

          const weatherRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
          if (!weatherRes.ok) return; // Silently fail if weather API is blocked
          
          const weatherData = await weatherRes.json();
          
          newItems.push({
            id: `weather-${Date.now()}`,
            text: `${city} Weather: ${weatherData.current_weather.temperature}°C`,
            type: 'weather',
            link: `https://duckduckgo.com/?q=weather+${encodeURIComponent(city)}`
          });
        } catch (e) {
          // Silently fail to avoid console errors if blocked by adblockers/network
        }
      };

      // 2. Fetch RSS Feeds
      const fetchRSS = async (url: string, type: TickerItem['type']) => {
        try {
          const response = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(url)}`);
          if (!response.ok) return; // Silently fail on non-200
          
          const data = await response.json();
          if (data && data.items && Array.isArray(data.items)) {
            data.items.slice(0, 4).forEach((item: any, i: number) => {
              newItems.push({
                id: `${type}-${i}-${Date.now()}`,
                text: item.title,
                type,
                link: item.link
              });
            });
          }
        } catch (e) {
          // Silently fail to avoid console errors if blocked by adblockers or rate limited
        }
      };

      // Run all fetches in parallel to avoid delays
      await Promise.allSettled([
        fetchWeather(),
        fetchRSS('http://feeds.bbci.co.uk/news/world/rss.xml', 'news'),
        fetchRSS('http://feeds.bbci.co.uk/news/technology/rss.xml', 'tech'),
        fetchRSS('http://feeds.bbci.co.uk/news/business/rss.xml', 'market'),
        fetchRSS('http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml', 'entertainment')
      ]);

      if (mounted && newItems.length > 0) {
        // Shuffle the items so it feels dynamic and varied
        const shuffled = newItems.sort(() => Math.random() - 0.5);
        setItems(shuffled);
      }
    }

    loadData();

    // Refresh data every 5 minutes
    const refreshInterval = setInterval(loadData, 5 * 60 * 1000);

    return () => {
      mounted = false;
      clearInterval(refreshInterval);
    };
  }, []);

  useEffect(() => {
    if (items.length <= 1) return;
    
    let timeout1: NodeJS.Timeout;
    let timeout2: NodeJS.Timeout;

    const cycle = () => {
      setIsVisible(true);
      // Persist for 3 seconds
      timeout1 = setTimeout(() => {
        setIsVisible(false);
        // Wait 4 seconds between topics
        timeout2 = setTimeout(() => {
          setCurrentIndex((prev) => (prev + 1) % items.length);
          cycle();
        }, 4000);
      }, 3000);
    };

    const initialDelay = setTimeout(() => {
      cycle();
    }, 1000);

    return () => {
      clearTimeout(timeout1);
      clearTimeout(timeout2);
      clearTimeout(initialDelay);
    };
  }, [items.length]);

  if (items.length === 0) return null;

  const currentItem = items[currentIndex];
  const showNotification = isVisible && !isStudyMode && isEnabled !== false;

  const icons = {
    weather: <CloudSun className="w-4 h-4 text-sky-400" />,
    tech: <Monitor className="w-4 h-4 text-emerald-400" />,
    market: <TrendingUp className="w-4 h-4 text-amber-400" />,
    entertainment: <Film className="w-4 h-4 text-purple-400" />,
    news: <Radio className="w-4 h-4 text-blue-400" />
  };

  return (
    <AnimatePresence>
      {showNotification && (
        <motion.a
          href={currentItem.link || '#'}
          target={currentItem.link ? "_blank" : undefined}
          rel="noopener noreferrer"
          onClick={(e) => { if (!currentItem.link) e.preventDefault(); }}
          initial={{ y: -20, opacity: 0, scale: 0.95 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: -20, opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          className={cn(
            "absolute top-20 left-1/2 -translate-x-1/2 z-40 max-w-[90%] sm:max-w-md w-full bg-surface/95 backdrop-blur-xl border border-border/60 rounded-2xl p-3 shadow-2xl shadow-black/10 flex items-center gap-3 overflow-hidden",
            currentItem.link ? "cursor-pointer hover:bg-surface transition-colors" : "cursor-default"
          )}
        >
          <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-bg border border-border shrink-0 shadow-inner">
            {icons[currentItem.type]}
          </div>
          <div className="flex flex-col min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-0.5">
              <span className="font-bold text-text-primary uppercase text-[9px] tracking-widest">
                {currentItem.type}
              </span>
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                <span className="text-[8px] font-black uppercase tracking-widest text-red-500">Live</span>
              </div>
            </div>
            <span className="text-xs font-medium text-text-secondary truncate w-full">
              {currentItem.text}
            </span>
          </div>
        </motion.a>
      )}
    </AnimatePresence>
  );
}
