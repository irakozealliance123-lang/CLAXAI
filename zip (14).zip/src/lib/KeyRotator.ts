export class KeyRotator {
  private keys: string[];
  public exhausted: Set<number>;
  private current: number;
  public name: string;

  constructor(name: string, keys: string[]) {
    this.name = name;
    this.keys = keys.filter(k => k.trim() !== '');
    this.exhausted = new Set();
    this.current = 0;
  }

  getNextKey(): { index: number; key: string } | null {
    for (let offset = 0; offset < this.keys.length; offset++) {
      const idx = (this.current + offset) % this.keys.length;
      if (!this.exhausted.has(idx)) {
        this.current = idx;
        return { index: idx, key: this.keys[idx] };
      }
    }
    return null;
  }

  markExhausted(index: number) {
    this.exhausted.add(index);
    this.current = (index + 1) % Math.max(this.keys.length, 1);
  }

  getAvailableCount() {
    return this.keys.length - this.exhausted.size;
  }
  
  getTotalCount() {
    return this.keys.length;
  }
  
  updateKeys(newKeys: string[]) {
    this.keys = newKeys.filter(k => k.trim() !== '');
    this.exhausted.clear();
    this.current = 0;
  }
  
  getKeys() {
    return this.keys;
  }
  
  getExhausted() {
    return this.exhausted;
  }
}
